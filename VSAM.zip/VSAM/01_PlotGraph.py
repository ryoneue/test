#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
How to run:
>> python 01_PlotGraph.py 
'''

from os import path
import numpy as np
import matplotlib.pyplot as plt

in_txt1 = open(path.join('data', 'car.txt'))
in_txt2 = open(path.join('data', 'human.txt'))

car = np.asarray([(line.strip()).split('\t') for line in in_txt1])
human = np.asarray([(line.strip()).split('\t') for line in in_txt2])

fig = plt.figure()
subfig = fig.add_subplot(1,1,1)
plt.xlim(xmin=0, xmax = 10000)
plt.ylim(ymin=20, ymax = 50)
subfig.scatter(car[:,0], car[:,1],color='blue')
subfig.scatter(human[:,0], human[:,1],color='red')

subfig.set_title('Feature Distribution')
subfig.set_xlabel('Area')
subfig.set_ylabel('complexity')

plt.savefig("01_graph.png")
plt.show()

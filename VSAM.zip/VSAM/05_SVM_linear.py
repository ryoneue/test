#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
How to run:
>> python 05_SVM_linear.py
'''

from os import path
import numpy as np
from sklearn import svm
from sklearn import metrics
from sklearn import cross_validation

in_txt1 = open(path.join('data', 'car.txt'))
in_txt2 = open(path.join('data', 'human.txt'))

car = np.asarray([(line.strip()).split('\t') for line in in_txt1], dtype=float)
print car.shape
human = np.asarray([(line.strip()).split('\t') for line in in_txt2], dtype=float)
print human.shape

car_y =  np.zeros(car.shape[0])
human_y = np.ones(human.shape[0])
X= np.r_[car, human]
y= np.r_[car_y, human_y]
kfold = cross_validation.KFold(len(X), n_folds=5, shuffle=True, random_state=0)
print X.shape, y.shape

scores = []
best_score = 0.0
c = 1.0
for train, test in kfold:
    classifier = svm.LinearSVC(C=c, random_state=0)
    classifier.fit(X[train], y[train])
    preds = classifier.predict(X[test])
    score = metrics.accuracy_score(preds, y[test])
    scores.append(score)

    if score > best_score:
        best_classifier = classifier
        best_score = score

accuracy = (sum(scores) / len(scores)) * 100
msg = 'recognition rate: {accuracy:.2f}%'.format(accuracy=accuracy)
print(msg)


import matplotlib.pyplot as plt

fig = plt.figure()
subfig = fig.add_subplot(1,1,1)
plt.xlim(xmin=0, xmax = 10000)
plt.ylim(ymin=20, ymax = 50)

xx, yy = np.meshgrid(np.linspace(plt.xlim()[0], plt.xlim()[1], 500),
                     np.linspace(plt.ylim()[0], plt.ylim()[1], 500))

Z = best_classifier.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)
cs = plt.contourf(xx, yy, Z, cmap=plt.cm.Paired)

subfig.scatter(car[:,0], car[:,1],color='black')
subfig.scatter(human[:,0], human[:,1],color='red')

subfig.set_title('05 SVM Linear')
subfig.set_xlabel('Area')
subfig.set_ylabel('complexity')

plt.savefig("05_graph"+str(c)+".png")
#plt.show()

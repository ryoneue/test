#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
How to run:
>> python 03_Mahalanobis.py
'''

from os import path
import numpy as np
from sklearn.covariance import EmpiricalCovariance

in_txt1 = open(path.join('data', 'car.txt'))
in_txt2 = open(path.join('data', 'human.txt'))

car = np.asarray([(line.strip()).split('\t') for line in in_txt1], dtype=float)
print car.shape
human = np.asarray([(line.strip()).split('\t') for line in in_txt2], dtype=float)
print human.shape

#calc cov each class
car_cov = EmpiricalCovariance().fit(car)
human_cov = EmpiricalCovariance().fit(human)

#calc distance each class for car data
car_mahal = car_cov.mahalanobis(car)
human_mahal = human_cov.mahalanobis(car)

car_correct = 0
for c_dist, h_dist in zip(car_mahal, human_mahal):
    if c_dist < h_dist:
        car_correct +=1
print 'car recognition rate : ' , car_correct / float(car.shape[0]) , '(' , car_correct ,'/', car.shape[0] , ')'

#calc distance each class for human data
car_mahal = car_cov.mahalanobis(human)
human_mahal = human_cov.mahalanobis(human)

human_correct = 0
for c_dist, h_dist in zip(car_mahal, human_mahal):
    if h_dist < c_dist:
        human_correct +=1
print 'human recognition rate : ' , human_correct / float(human.shape[0]), '(' , human_correct ,'/', human.shape[0] , ')'

print 'average recognition rate : ' , ( car_correct / float(car.shape[0]) + human_correct / float(human.shape[0]) ) / 2.0

#data plot
import matplotlib.pyplot as plt

fig = plt.figure()
subfig = fig.add_subplot(1, 1, 1)
plt.xlim(xmin=0, xmax = 10000)
plt.ylim(ymin=20, ymax = 50)

#Show contours of the distance functions
xx, yy = np.meshgrid(np.linspace(plt.xlim()[0], plt.xlim()[1], 500),
                     np.linspace(plt.ylim()[0], plt.ylim()[1], 500))
zz = np.c_[xx.ravel(), yy.ravel()]

car_mahal_emp_cov = car_cov.mahalanobis(zz)
car_mahal_emp_cov_reshape = car_mahal_emp_cov.reshape(xx.shape)

human_mahal_emp_cov = human_cov.mahalanobis(zz)
human_mahal_emp_cov_reshape = human_mahal_emp_cov.reshape(xx.shape)

Z = []
for c_dist, h_dist in zip(car_mahal_emp_cov, human_mahal_emp_cov):
    if c_dist < h_dist:
        Z.append(0)
    else:
        Z.append(1)
Z = np.asarray(Z)
Z = Z.reshape(xx.shape)
cs = plt.contourf(xx, yy, Z, cmap=plt.cm.Paired)

levels = [0.03, 1, 2, 3, 4]
car_emp_cov_contour = subfig.contour(xx, yy, np.sqrt(car_mahal_emp_cov_reshape), levels,
                                     cmap=plt.cm.PuBu_r,
                                     linestyles='solid')
human_emp_cov_contour = subfig.contour(xx, yy, np.sqrt(human_mahal_emp_cov_reshape), levels,
                                       cmap=plt.cm.YlOrRd_r,
                                       linestyles='solid')


car_plot = subfig.scatter(car[:, 0], car[:, 1], color='blue', label='car')
human_plot = subfig.scatter(human[:, 0], human[:, 1], color='red', label='human')

test = np.array([[2000.0, 40.0]])
# #calc cov each class
# car_cov = EmpiricalCovariance().fit(test)
# human_cov = EmpiricalCovariance().fit(test)

#calc distance each class for car data
car_mahal = car_cov.mahalanobis(test)
human_mahal = human_cov.mahalanobis(test)

print car_mahal, human_mahal

subfig.set_title('03 Mahalanobis Distance')
subfig.set_xlabel('Area')
subfig.set_ylabel('complexity')




plt.savefig("03_graph.png")
plt.show()

#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
How to run:
>> python 02_Euclid.py
'''

from os import path
import numpy as np

in_txt1 = open(path.join('data', 'car.txt'))
in_txt2 = open(path.join('data', 'human.txt'))

car = np.asarray([(line.strip()).split('\t') for line in in_txt1], dtype=float)
print car.shape
human = np.asarray([(line.strip()).split('\t') for line in in_txt2], dtype=float)
print human.shape

car_mean = np.array([ np.mean(car[:,0]), np.mean(car[:,1]) ])
human_mean = np.array([ np.mean(human[:,0]), np.mean(human[:,1]) ])

car_mean_test = np.array([car_mean[0], ( car_mean[1] - 20.0 ) * 266.7 ])
human_mean_test = np.array([ human_mean[0], ( human_mean[1] - 20.0 ) * 266.7 ])

car_test = np.c_[ car[:,0], ( car[:,1] - 20.0 ) * 266.7 ]
human_test = np.c_[ human[:,0], ( human[:,1] - 20.0 ) * 266.7 ]

#calc distance each mean for car data
car_correct = 0
for i in range(0,car_test.shape[0]):
    human_dist = np.linalg.norm( car_test[i] - human_mean_test )
    car_dist = np.linalg.norm( car_test[i] - car_mean_test )
    if car_dist < human_dist:
        car_correct += 1

print 'car recognition rate : ' , car_correct / float(car.shape[0]) , '(' , car_correct ,'/', car.shape[0] , ')'

#calc distance each mean for human data
human_correct = 0
for i in range(0,human_test.shape[0]):
    human_dist = np.linalg.norm( human_test[i] - human_mean_test )
    car_dist = np.linalg.norm( human_test[i] - car_mean_test )
    if human_dist < car_dist:
        human_correct += 1

print 'human recognition rate : ' , human_correct / float(human.shape[0]), '(' , human_correct ,'/', human.shape[0] , ')'

print 'average recognition rate : ' , ( car_correct / float(car.shape[0]) + human_correct / float(human.shape[0]) ) / 2.0

# make graph
import matplotlib.pyplot as plt

fig = plt.figure()
subfig = fig.add_subplot(1,1,1)
plt.xlim(xmin=0, xmax = 10000)
plt.ylim(ymin=20, ymax = 50)

xx, yy = np.meshgrid(np.linspace(plt.xlim()[0], plt.xlim()[1], 500),
                     np.linspace(plt.ylim()[0], plt.ylim()[1], 500))

graphdata = np.c_[xx.ravel(), ( yy.ravel() - 20.0 ) * 266.7 ]
Z = []
for i in range(0, graphdata.shape[0]):
    human_dist = np.linalg.norm( graphdata[i] - human_mean_test )
    car_dist = np.linalg.norm( graphdata[i] - car_mean_test )
    if car_dist < human_dist:
        Z.append(0)
    else:
        Z.append(1)

Z = np.asarray(Z)
Z = Z.reshape(xx.shape)
cs = plt.contourf(xx, yy, Z, cmap=plt.cm.Paired)

subfig.scatter(car[:,0], car[:,1],color='black')
subfig.scatter(human[:,0], human[:,1],color='red')

subfig.plot(human_mean[0], human_mean[1], color="r", marker="x", markersize=15)
subfig.plot(car_mean[0], car_mean[1],  color="k", marker="x", markersize=15)

subfig.set_title('02 Euclid Distance')
subfig.set_xlabel('Area')
subfig.set_ylabel('complexity')

test = np.array([[2000.0, 40.0]])

human_dist = np.linalg.norm( test - human_mean_test )
car_dist = np.linalg.norm( test - car_mean_test )
print human_dist, car_dist

plt.savefig("02_graph.png")
plt.show()

#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
How to run:
>> python 04_kNN.py
'''

from os import path
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics

in_txt1 = open(path.join('data', 'car.txt'))
in_txt2 = open(path.join('data', 'human.txt'))

car = np.asarray([(line.strip()).split('\t') for line in in_txt1], dtype=float)
print car.shape
human = np.asarray([(line.strip()).split('\t') for line in in_txt2], dtype=float)
print human.shape

car_y =  np.zeros(car.shape[0])
human_y = np.ones(human.shape[0])
X= np.r_[car, human]
y= np.r_[car_y, human_y]
print X.shape, y.shape

X_train = np.c_[ X[:,0], ( X[:,1] - 20.0 ) * 266.7 ]

n_neighbors = 5

# train
classifier = KNeighborsClassifier(algorithm='brute', n_neighbors=n_neighbors)
classifier.fit(X_train, y)

import matplotlib.pyplot as plt

fig = plt.figure()
subfig = fig.add_subplot(1,1,1)
plt.xlim(xmin=0, xmax = 10000)
plt.ylim(ymin=20, ymax = 50)

xx, yy = np.meshgrid(np.linspace(plt.xlim()[0], plt.xlim()[1], 500),
                     np.linspace(plt.ylim()[0], plt.ylim()[1], 500))

Z = classifier.predict(np.c_[xx.ravel(), ( yy.ravel() - 20.0 ) * 266.7 ])
Z = Z.reshape(xx.shape)
cs = plt.contourf(xx, yy, Z, cmap=plt.cm.Paired)

subfig.scatter(car[:,0], car[:,1],color='black')
subfig.scatter(human[:,0], human[:,1],color='red')

subfig.set_title('04 kNN k=' + str(n_neighbors))
subfig.set_xlabel('Area')
subfig.set_ylabel('complexity')

plt.savefig("04_graph.png")
plt.show()
